return {
    ["mobile"]={
        ["android"] = "Android",
        ["iphone"] = "(iPhone|iPod|iPad)"
    },
    ["pc"] = {
        ["firefox"] = "Firefox",
        ["msie"] = "MSIE",
        ["qh360"] = "360SE",
        ["theworld"] = "The World",
        ["tt"] = "TencentTraveler",
        ["maxthon"] = "Maxthon",
        ["opera"] = "Opera",
        ["qq"] = "QQBrowser",
        ["uc"] = "(UCWEB|UBrowser)",
        ["safari"] = "Safari",
        ["chrome"] = "Chrome",
        ["metasr"] = "MetaSr",
        ["pc2345"] = "2345Explorer",
        ["edeg"] = "Edg[e]*"
    },
    ["os"] = {
        ["windows"] = "Windows",
        ["linux"] = "Linux",
        ["mac"] = "Macintosh"
    },
    ["other"] = {
        ["weixin"] = "MicroMessenger"
    }
}